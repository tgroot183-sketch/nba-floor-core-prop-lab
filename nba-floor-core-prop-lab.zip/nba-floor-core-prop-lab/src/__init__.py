# Marks src as a package.
