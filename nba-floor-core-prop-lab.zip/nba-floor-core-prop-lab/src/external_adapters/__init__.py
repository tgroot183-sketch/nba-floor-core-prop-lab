# Adapters for projections (ML or manual).
